
export const SYLLABUS_DB: Record<string, Record<number, Record<number, {name: string, credits: number, topics: string[]}[]>>> = {
  "Computer Science": {
    1: {
      1: [
        { name: "Engineering Mathematics I", credits: 4, topics: ["Calculus", "Linear Algebra", "Complex Numbers"] },
        { name: "Programming in C", credits: 3, topics: ["Loops", "Arrays", "Pointers", "Structures"] },
        { name: "Basic Electronics", credits: 3, topics: ["Semiconductors", "Diodes", "Transistors"] }
      ],
      2: [
        { name: "Engineering Mathematics II", credits: 4, topics: ["Differential Equations", "Vector Calculus"] },
        { name: "Data Structures", credits: 4, topics: ["Linked Lists", "Stacks", "Queues", "Trees", "Hashing"] },
        { name: "Digital Logic Design", credits: 3, topics: ["Gates", "K-Maps", "Flip-Flops", "Registers"] }
      ]
    },
    2: {
      3: [
        { name: "Discrete Mathematics", credits: 4, topics: ["Set Theory", "Graph Theory", "Logic"] },
        { name: "Operating Systems", credits: 4, topics: ["CPU Scheduling", "Deadlocks", "Memory Management"] },
        { name: "Computer Organization", credits: 3, topics: ["ALU", "Cache Memory", "Pipelining"] }
      ]
    }
  },
  "Mechanical": {
    1: {
      1: [
        { name: "Engineering Physics", credits: 4, topics: ["Optics", "Thermodynamics", "Quantum Mechanics"] },
        { name: "Engineering Mechanics", credits: 4, topics: ["Statics", "Dynamics", "Trusses"] }
      ]
    },
    2: {
      3: [
        { name: "Thermodynamics", credits: 4, topics: ["First Law", "Second Law", "Entropy", "Cycles"] },
        { name: "Material Science", credits: 3, topics: ["Crystal Structures", "Phase Diagrams", "Iron-Carbon"] }
      ]
    }
  },
  "Electrical": {
    1: {
      1: [
        { name: "Network Theory", credits: 4, topics: ["KVL", "KCL", "Thevenin", "Norton"] },
        { name: "Engineering Chemistry", credits: 3, topics: ["Polymers", "Corrosion", "Batteries"] }
      ]
    }
  }
};
