
import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, UserContext, StudyPlan } from '../types';
import { getEngiBotResponse } from '../services/geminiService';

interface EngiBotProps {
  context?: UserContext;
  plan?: StudyPlan;
}

const EngiBot: React.FC<EngiBotProps> = ({ context, plan }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: 'SYSTEM READY. ENGIBOT v4.2 ONLINE. STATE YOUR ACADEMIC QUERY.' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    
    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      const response = await getEngiBotResponse(messages, userMsg, context, plan);
      setMessages(prev => [...prev, { role: 'model', text: response || 'TRANSMISSION ERROR.' }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'model', text: 'CORE_SYNC_FAILURE. RETRY.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-10 right-10 z-[100] flex flex-col items-end">
      {isOpen && (
        <div className="mb-6 w-96 h-[550px] bg-slate-950 border border-cyan-500/50 flex flex-col overflow-hidden animate-in slide-in-from-bottom-6 duration-300 shadow-[0_0_50px_rgba(6,182,212,0.15)] rounded-none">
          <div className="bg-cyan-500 p-5 flex items-center justify-between text-slate-950">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-slate-950 text-cyan-400 flex items-center justify-center font-black text-xs mono">AI</div>
              <div>
                <h3 className="font-black text-xs mono tracking-widest uppercase">ENGIBOT_ASSISTANT</h3>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="w-1.5 h-1.5 bg-slate-950 rounded-full animate-pulse"></span>
                  <span className="text-[8px] font-black uppercase mono opacity-70">NEURAL_LINK_OK</span>
                </div>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:scale-110 transition-transform">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>

          <div ref={scrollRef} className="flex-grow overflow-y-auto p-6 space-y-6 custom-scrollbar bg-black/50 cyber-grid">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[90%] p-4 text-xs mono uppercase tracking-tighter ${
                  m.role === 'user' 
                    ? 'bg-slate-900 border border-slate-700 text-white rounded-none' 
                    : 'bg-cyan-500/5 border border-cyan-500/30 text-cyan-400 rounded-none'
                }`}>
                  <span className="text-[10px] opacity-50 block mb-1">[{m.role.toUpperCase()}_LOG]</span>
                  {m.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="text-cyan-400 animate-pulse mono text-[10px] tracking-widest uppercase">
                  DECRYPTING_THOUGHTS...
                </div>
              </div>
            )}
          </div>

          <div className="p-6 bg-slate-950 border-t border-slate-900">
            <div className="flex gap-4">
              <input 
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="INPUT_COMMAND..."
                className="flex-grow bg-black border border-slate-800 text-white rounded-none px-4 py-3 text-xs mono outline-none focus:border-cyan-500 transition-colors"
              />
              <button 
                onClick={handleSend}
                disabled={isLoading}
                className="bg-cyan-500 text-slate-950 p-3 hover:bg-white transition-colors disabled:opacity-50"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
              </button>
            </div>
          </div>
        </div>
      )}

      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-16 h-16 bg-cyan-500 rounded-none shadow-[0_0_20px_rgba(6,182,212,0.4)] flex items-center justify-center text-slate-950 hover:scale-105 transition-all hover:bg-white group overflow-hidden relative"
      >
        <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-20 transition-opacity rotate-45"></div>
        {isOpen ? (
          <svg className="w-8 h-8 relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12" /></svg>
        ) : (
          <svg className="w-8 h-8 relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
        )}
      </button>
    </div>
  );
};

export default EngiBot;
