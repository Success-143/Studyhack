
import React, { useState } from 'react';
import { SubjectInput, UserContext } from '../types';
import { SYLLABUS_DB } from '../constants/syllabus';

interface StudyFormProps {
  onSubmit: (context: UserContext) => void;
  loading: boolean;
}

const StudyForm: React.FC<StudyFormProps> = ({ onSubmit, loading }) => {
  const [context, setContext] = useState<UserContext>({
    year: 1,
    semester: 1,
    major: 'Computer Science',
    availableHoursPerDay: 4,
    peakFocusHours: 'morning',
    subjects: [
      { id: '1', name: '', credits: 3, confidence: 3, topics: [] }
    ]
  });

  const majors = Object.keys(SYLLABUS_DB);

  const autoFillSyllabus = () => {
    const majorData = SYLLABUS_DB[context.major || ''];
    if (majorData && majorData[context.year] && majorData[context.year][context.semester]) {
      const subjects = majorData[context.year][context.semester].map(s => ({
        id: Math.random().toString(36).substr(2, 9),
        name: s.name,
        credits: s.credits,
        confidence: 3,
        topics: s.topics
      }));
      setContext({ ...context, subjects });
    }
  };

  const addSubject = () => {
    setContext({
      ...context,
      subjects: [...context.subjects, { id: Date.now().toString(), name: '', credits: 3, confidence: 3, topics: [] }]
    });
  };

  const removeSubject = (id: string) => {
    setContext({ ...context, subjects: context.subjects.filter(s => s.id !== id) });
  };

  const updateSubject = (id: string, updates: Partial<SubjectInput>) => {
    setContext({
      ...context,
      subjects: context.subjects.map(s => s.id === id ? { ...s, ...updates } : s)
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(context);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-slate-900/40 p-10 border border-slate-800 backdrop-blur-md max-w-5xl mx-auto shadow-2xl relative overflow-hidden group">
      <div className="absolute top-0 left-0 w-2 h-2 bg-cyan-500"></div>
      <div className="absolute top-0 right-0 w-2 h-2 bg-cyan-500"></div>
      <div className="absolute bottom-0 left-0 w-2 h-2 bg-cyan-500"></div>
      <div className="absolute bottom-0 right-0 w-2 h-2 bg-cyan-500"></div>

      <div className="flex items-center gap-4 mb-10 pb-6 border-b border-slate-800">
        <div className="bg-cyan-500 p-2 shrink-0">
          <svg className="w-6 h-6 text-slate-950" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
          </svg>
        </div>
        <div>
          <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">DATA_ENTRY_PORTAL</h2>
          <p className="text-[10px] text-slate-500 mono uppercase tracking-[0.2em]">Syllabus Parser v1.02a</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
        {[
          { label: 'SELECT_MAJOR', key: 'major', type: 'select', options: majors },
          { label: 'ACADEMIC_YEAR', key: 'year', type: 'select', options: [1, 2, 3, 4, 5] },
          { label: 'SEMESTER', key: 'semester', type: 'select', options: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] },
          { label: 'DAILY_UPTIME (HR)', key: 'availableHoursPerDay', type: 'number' }
        ].map((field) => (
          <div key={field.label} className="space-y-2">
            <label className="text-[10px] font-black text-cyan-400 mono uppercase tracking-widest">{field.label}</label>
            {field.type === 'select' ? (
              <select 
                className="w-full bg-slate-950 border border-slate-800 text-white rounded-none px-4 py-3 outline-none focus:border-cyan-500 transition-colors mono text-sm"
                value={(context as any)[field.key]}
                onChange={(e) => setContext({...context, [field.key]: e.target.value})}
              >
                {field.options?.map(opt => <option key={opt} value={opt}>{field.key === 'major' ? opt : `V${opt}.0`}</option>)}
              </select>
            ) : (
              <input 
                type="number"
                className="w-full bg-slate-950 border border-slate-800 text-white rounded-none px-4 py-3 outline-none focus:border-cyan-500 transition-colors mono text-sm"
                value={(context as any)[field.key]}
                onChange={(e) => setContext({...context, [field.key]: parseInt(e.target.value)})}
              />
            )}
          </div>
        ))}
      </div>

      <div className="mb-12">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <h3 className="text-xl font-bold text-white uppercase tracking-tighter flex items-center gap-2">
            <span className="w-1 h-5 bg-cyan-500"></span>
            PAPER_MODULES
          </h3>
          <div className="flex gap-4">
            <button 
              type="button"
              onClick={autoFillSyllabus}
              className="px-6 py-2 bg-transparent border border-cyan-500 text-cyan-500 text-[10px] font-black uppercase hover:bg-cyan-500 hover:text-slate-950 transition-all mono tracking-widest"
            >
              FETCH_STANDARD_DB
            </button>
            <button 
              type="button"
              onClick={addSubject}
              className="px-6 py-2 bg-slate-800 text-slate-300 text-[10px] font-black uppercase hover:text-white transition-all mono tracking-widest"
            >
              + ADD_CUSTOM
            </button>
          </div>
        </div>

        <div className="space-y-6 max-h-[500px] overflow-y-auto pr-4 custom-scrollbar">
          {context.subjects.map((subject, idx) => (
            <div key={subject.id} className="p-6 bg-slate-950/50 border border-slate-800 flex flex-col lg:flex-row gap-6 items-end relative group/item">
              <div className="absolute top-2 right-2 text-[10px] text-slate-800 mono">ID_{subject.id.slice(0,4)}</div>
              <div className="flex-grow space-y-2 w-full">
                <label className="text-[10px] font-bold text-slate-500 mono uppercase tracking-widest">MODULE_NAME</label>
                <input 
                  type="text" 
                  className="w-full bg-slate-900 border border-slate-800 text-white rounded-none px-4 py-3 outline-none focus:border-cyan-500 transition-colors mono text-sm"
                  value={subject.name}
                  onChange={(e) => updateSubject(subject.id, { name: e.target.value })}
                  required
                />
              </div>
              <div className="w-full lg:w-32 space-y-2">
                <label className="text-[10px] font-bold text-slate-500 mono uppercase tracking-widest">CREDITS</label>
                <input 
                  type="number" 
                  className="w-full bg-slate-900 border border-slate-800 text-white rounded-none px-4 py-3 outline-none focus:border-cyan-500 transition-colors mono text-sm text-center"
                  value={subject.credits}
                  onChange={(e) => updateSubject(subject.id, { credits: parseInt(e.target.value) })}
                  required
                />
              </div>
              <div className="w-full lg:w-64 space-y-2">
                <label className="text-[10px] font-bold text-slate-500 mono uppercase tracking-widest">CONFIDENCE_INDEX</label>
                <div className="flex gap-2 justify-between bg-slate-900 border border-slate-800 p-1.5">
                  {[1,2,3,4,5].map(v => (
                    <button
                      key={v}
                      type="button"
                      onClick={() => updateSubject(subject.id, { confidence: v })}
                      className={`flex-1 h-10 text-xs font-black transition-all mono ${subject.confidence === v ? 'bg-cyan-500 text-slate-950 shadow-[0_0_15px_rgba(6,182,212,0.5)]' : 'text-slate-600 hover:text-cyan-400'}`}
                    >
                      {v}
                    </button>
                  ))}
                </div>
              </div>
              {context.subjects.length > 1 && (
                <button 
                  type="button"
                  onClick={() => removeSubject(subject.id)}
                  className="p-3 text-slate-700 hover:text-red-500 transition-colors mb-0.5"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      <button
        type="submit"
        disabled={loading}
        className={`w-full py-6 rounded-none font-black text-xl flex items-center justify-center gap-4 transition-all tracking-[0.2em] uppercase ${loading ? 'bg-slate-800 cursor-wait text-slate-500' : 'bg-cyan-500 hover:bg-white text-slate-950 shadow-2xl shadow-cyan-500/20'}`}
      >
        {loading ? (
          <>
            <div className="w-5 h-5 border-2 border-slate-500 border-t-cyan-500 rounded-full animate-spin"></div>
            PROCESSING_ALGORITHM...
          </>
        ) : (
          <>
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
            ARCHITECT_SYLLABUS
          </>
        )}
      </button>
    </form>
  );
};

export default StudyForm;
