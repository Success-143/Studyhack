
import React from 'react';
import { StudyPlan, CognitiveLoad, ActivityType } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface PlanDashboardProps {
  plan: StudyPlan;
}

const COLORS = ['#06b6d4', '#d946ef', '#84cc16', '#f59e0b', '#ef4444', '#6366f1'];

const PlanDashboard: React.FC<PlanDashboardProps> = ({ plan }) => {
  const getActivityColor = (type: ActivityType) => {
    switch (type) {
      case ActivityType.LEARNING: return 'bg-cyan-500/10 border-cyan-500 text-cyan-400';
      case ActivityType.PRACTICE: return 'bg-lime-500/10 border-lime-500 text-lime-400';
      case ActivityType.REVISION: return 'bg-magenta-500/10 border-magenta-500 text-magenta-400';
      case ActivityType.BUFFER: return 'bg-orange-500/10 border-orange-500 text-orange-400';
      default: return 'bg-slate-800 border-slate-700 text-slate-400';
    }
  };

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-8 duration-1000">
      {/* Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { label: 'COMPLETION_TIMELINE', value: plan.outcomeSummary.completionTimeline, color: 'text-white' },
          { label: 'CONFIDENCE_PROJECTION', value: plan.outcomeSummary.expectedConfidenceImprovement, color: 'text-cyan-400' },
          { label: 'WORKLOAD_OPTIMIZATION', value: plan.outcomeSummary.workloadReductionImpact, color: 'text-lime-400' }
        ].map((m, i) => (
          <div key={i} className="bg-slate-900 border-l-2 border-slate-700 p-8 group hover:border-cyan-500 transition-colors">
            <h3 className="text-slate-500 text-[10px] font-black tracking-widest uppercase mono mb-3"># {m.label}</h3>
            <p className={`text-2xl font-black italic uppercase ${m.color} tracking-tighter`}>{m.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div className="bg-slate-900 p-8 border border-slate-800 relative">
          <div className="absolute top-0 right-0 p-4 mono text-[8px] text-slate-700">VISUAL_THROUGHPUT_v2</div>
          <h3 className="text-lg font-black text-white mb-8 flex items-center gap-3 italic uppercase">
            <span className="w-1.5 h-6 bg-cyan-500"></span>
            ALLOCATION_INDEX [WEEKLY]
          </h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={plan.breakdown}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                <XAxis dataKey="name" fontSize={10} tick={{ fill: '#475569' }} axisLine={false} tickLine={false} />
                <YAxis fontSize={10} tick={{ fill: '#475569' }} axisLine={false} tickLine={false} />
                <Tooltip 
                  cursor={{ fill: '#0f172a' }}
                  contentStyle={{ backgroundColor: '#020617', border: '1px solid #1e293b', borderRadius: '0', color: '#fff' }}
                />
                <Bar dataKey="hoursPerWeek" radius={[0, 0, 0, 0]}>
                  {plan.breakdown.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 p-8 border border-slate-800 relative overflow-hidden">
          <div className="absolute -right-10 top-10 opacity-[0.03] text-8xl font-black text-white select-none pointer-events-none rotate-90 mono">JUSTIFICATION</div>
          <h3 className="text-lg font-black text-white mb-8 flex items-center gap-3 italic uppercase">
            <span className="w-1.5 h-6 bg-magenta-500"></span>
            LOGIC_VERIFICATION
          </h3>
          <div className="space-y-6 max-h-72 overflow-y-auto custom-scrollbar pr-4">
            {plan.breakdown.map((item, idx) => (
              <div key={idx} className="p-4 bg-slate-950 border-l-2 border-slate-800 group hover:border-cyan-500 transition-colors">
                <div className="flex justify-between items-start mb-2">
                  <span className="font-black text-white mono text-xs tracking-tighter uppercase">{item.name}</span>
                  <span className="text-[10px] font-black text-cyan-400 bg-cyan-500/10 px-2 py-0.5 mono">
                    {item.allocationPercentage}%_THR
                  </span>
                </div>
                <p className="text-xs text-slate-500 mono leading-relaxed uppercase">"{item.justification}"</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-slate-900 p-8 border border-slate-800">
        <h3 className="text-xl font-black text-white mb-10 flex items-center justify-between italic uppercase">
          <div className="flex items-center gap-3">
            <span className="w-1.5 h-6 bg-lime-500"></span>
            CHRONO_MAP_ACTIVE
          </div>
          <div className="mono text-[10px] text-slate-700">GRID_RES: DAILY_SLOTS</div>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-7 gap-6">
          {days.map((day) => {
            const slots = plan.schedule.filter(s => s.day === day);
            return (
              <div key={day} className="flex flex-col space-y-4">
                <div className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] text-center border-b border-slate-800 pb-3 mono">
                  {day.substring(0, 3)}
                </div>
                {slots.length > 0 ? (
                  slots.map((slot, idx) => (
                    <div 
                      key={idx} 
                      className={`p-4 border-l-4 flex flex-col gap-2 transition-all hover:translate-x-1 ${getActivityColor(slot.activityType)}`}
                    >
                      <div className="text-[9px] font-black opacity-80 mono tracking-tighter">
                        [{slot.startTime} // {slot.endTime}]
                      </div>
                      <div className="font-black text-xs uppercase tracking-tight truncate">{slot.subjectName}</div>
                      <div className="flex items-center gap-2">
                         <span className="text-[8px] font-black uppercase mono bg-white/10 px-1.5 py-0.5">{slot.activityType}</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-[8px] text-slate-700 text-center py-6 italic mono uppercase">VOID_SLOT</div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="bg-slate-900 p-10 border border-slate-800">
          <h3 className="text-xl font-black text-white mb-8 italic uppercase tracking-tighter">IMMEDIATE_ACTIONS</h3>
          <div className="space-y-8">
            {plan.nextSteps.map((step, idx) => (
              <div key={idx} className="flex gap-6 items-start group">
                <div className="flex-shrink-0 w-10 h-10 bg-slate-950 border border-slate-800 group-hover:border-cyan-500 flex items-center justify-center font-black text-cyan-400 mono text-sm transition-colors">
                  {idx + 1}
                </div>
                <div className="space-y-1">
                  <div className="text-[10px] font-black text-cyan-500 uppercase tracking-[0.2em] mono">{step.timeframe}</div>
                  <div className="font-black text-white uppercase italic text-sm">{step.task}</div>
                  <div className="text-xs text-slate-500 mono leading-relaxed uppercase">{step.reason}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-black text-white p-10 border border-slate-800 shadow-[inset_0_0_50px_rgba(0,0,0,1)] relative overflow-hidden">
          <div className="absolute inset-0 cyber-grid opacity-10"></div>
          <h3 className="text-xl font-black mb-8 flex items-center gap-3 italic uppercase relative z-10">
            <svg className="w-6 h-6 text-cyan-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            ARCHITECT_LOG_v1
          </h3>
          <p className="text-slate-400 leading-relaxed text-sm mono uppercase relative z-10">
            {plan.prioritizationLogic}
          </p>
          <div className="mt-10 pt-10 border-t border-slate-900 flex flex-col gap-4 relative z-10">
             {[
               { label: 'PEAK_PERFORMANCE_OVERRIDE', active: true },
               { label: 'PREREQUISITE_SYNC_COMPLETE', active: true },
               { label: 'DYNAMIC_BUFFER_ALLOCATION', active: true }
             ].map((st, i) => (
               <div key={i} className="flex items-center gap-3 text-[10px] mono font-black">
                 <div className={`w-2 h-2 rounded-full ${st.active ? 'bg-cyan-500 shadow-[0_0_8px_#22d3ee]' : 'bg-slate-700'}`}></div>
                 <span className="text-slate-500 tracking-[0.2em] uppercase">{st.label}</span>
               </div>
             ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlanDashboard;
