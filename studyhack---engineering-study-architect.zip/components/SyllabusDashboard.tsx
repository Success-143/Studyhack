
import React, { useState } from 'react';
import { SubjectInput } from '../types';

interface SyllabusDashboardProps {
  subjects: SubjectInput[];
}

const SyllabusDashboard: React.FC<SyllabusDashboardProps> = ({ subjects }) => {
  const [selectedSubjectId, setSelectedSubjectId] = useState<string | null>(null);

  const selectedSubject = subjects.find(s => s.id === selectedSubjectId);

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-right-8 duration-700">
      <div className="flex items-center justify-between border-b border-slate-800 pb-6">
        <h3 className="text-2xl font-black text-white italic uppercase tracking-tighter flex items-center gap-3">
          <span className="w-2 h-8 bg-cyan-500"></span>
          SYLLABUS_REPOSITORY
        </h3>
        <div className="mono text-[10px] text-slate-500 uppercase tracking-[0.2em]">
          Accessing Central Database...
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {subjects.map((subject) => (
          <button
            key={subject.id}
            onClick={() => setSelectedSubjectId(subject.id === selectedSubjectId ? null : subject.id)}
            className={`group relative p-6 border text-left transition-all duration-300 overflow-hidden ${
              selectedSubjectId === subject.id 
                ? 'bg-cyan-500 border-cyan-400' 
                : 'bg-slate-900 border-slate-800 hover:border-cyan-500 hover:bg-slate-800'
            }`}
          >
            <div className="absolute top-0 right-0 p-2 mono text-[8px] opacity-30">
              SEC_LEVEL_{subject.credits}
            </div>
            
            <div className="flex flex-col gap-2">
              <span className={`text-[10px] font-black mono tracking-[0.2em] uppercase ${
                selectedSubjectId === subject.id ? 'text-slate-950' : 'text-cyan-400'
              }`}>
                [ DATA_MODULE ]
              </span>
              <h4 className={`text-xl font-black uppercase italic tracking-tighter leading-tight ${
                selectedSubjectId === subject.id ? 'text-slate-950' : 'text-white'
              }`}>
                {subject.name}
              </h4>
              <div className={`h-1 w-12 transition-all duration-300 ${
                selectedSubjectId === subject.id ? 'bg-slate-950 w-full' : 'bg-slate-700'
              }`}></div>
            </div>

            <div className={`mt-4 flex items-center gap-2 text-[10px] font-black mono uppercase ${
              selectedSubjectId === subject.id ? 'text-slate-900' : 'text-slate-500'
            }`}>
              <svg className={`w-4 h-4 transition-transform duration-300 ${selectedSubjectId === subject.id ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M19 9l-7 7-7-7" />
              </svg>
              {selectedSubjectId === subject.id ? 'CLOSE_DATA_LINK' : 'EXPAND_SYLLABUS'}
            </div>
          </button>
        ))}
      </div>

      {selectedSubject && (
        <div className="animate-in fade-in slide-in-from-top-4 duration-500">
          <div className="bg-slate-900 border border-cyan-500 p-8 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent opacity-50"></div>
            <div className="absolute -right-20 -bottom-10 opacity-[0.05] text-9xl font-black text-white select-none pointer-events-none italic mono">
              DATA_LINK
            </div>
            
            <div className="relative z-10 space-y-8">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
                <div>
                  <h4 className="text-3xl font-black text-white italic uppercase tracking-tighter">
                    {selectedSubject.name} // FULL_SYLLABUS
                  </h4>
                  <div className="flex gap-4 mt-2">
                    <span className="text-[10px] font-black text-cyan-400 mono bg-cyan-500/10 px-2 py-1">CREDITS: {selectedSubject.credits}.0</span>
                    <span className="text-[10px] font-black text-magenta-400 mono bg-magenta-500/10 px-2 py-1">LOAD: {selectedSubject.credits > 3 ? 'HIGH' : 'MEDIUM'}</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h5 className="text-xs font-black text-slate-500 uppercase tracking-[0.3em] mb-4 mono flex items-center gap-2">
                    <span className="w-1 h-3 bg-cyan-500"></span>
                    CORE_TOPICS_INDEX
                  </h5>
                  <div className="space-y-3">
                    {selectedSubject.topics.length > 0 ? (
                      selectedSubject.topics.map((topic, i) => (
                        <div key={i} className="flex items-center gap-4 bg-slate-950 p-4 border border-slate-800 group hover:border-cyan-500 transition-colors">
                          <span className="text-cyan-500 mono font-bold text-xs">{(i + 1).toString().padStart(2, '0')}</span>
                          <span className="text-sm font-bold text-slate-300 uppercase tracking-tight group-hover:text-white transition-colors">{topic}</span>
                        </div>
                      ))
                    ) : (
                      <div className="p-4 border border-dashed border-slate-800 text-slate-600 mono text-xs uppercase text-center italic">
                        No sub-topics indexed in current dataset.
                      </div>
                    )}
                  </div>
                </div>

                <div className="bg-black/40 border border-slate-800 p-6 flex flex-col justify-center items-center text-center space-y-4">
                  <div className="w-16 h-16 border border-cyan-500/30 rounded-full flex items-center justify-center animate-pulse">
                    <svg className="w-8 h-8 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                    </svg>
                  </div>
                  <h6 className="text-white font-black uppercase text-sm italic">SYSTEM_INSIGHT</h6>
                  <p className="text-xs text-slate-500 mono leading-relaxed uppercase max-w-xs">
                    This module is prioritized for Year {selectedSubject.id.length % 4 + 1} integration. Automated deep-learning schedule has been optimized for the associated cognitive load.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SyllabusDashboard;
