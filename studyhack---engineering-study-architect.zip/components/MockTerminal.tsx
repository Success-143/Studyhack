
import React, { useState } from 'react';
import { generateMockTest, generateImprovementPlan } from '../services/geminiService';
import { MockQuestion, TestResult, ImprovementPlan, UserContext } from '../types';

interface MockTerminalProps {
  context?: UserContext;
}

const MockTerminal: React.FC<MockTerminalProps> = ({ context }) => {
  const [state, setState] = useState<'IDLE' | 'LOADING' | 'QUIZ' | 'SCORING' | 'RESULT'>('IDLE');
  const [questions, setQuestions] = useState<MockQuestion[]>([]);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [results, setResults] = useState<TestResult[]>([]);
  const [improvementPlan, setImprovementPlan] = useState<ImprovementPlan | null>(null);

  const startTest = async () => {
    if (!context || context.subjects.length === 0) return;
    setState('LOADING');
    try {
      const q = await generateMockTest(context.subjects.map(s => s.name));
      setQuestions(q);
      setAnswers({});
      setState('QUIZ');
    } catch (e) {
      console.error(e);
      setState('IDLE');
    }
  };

  const submitQuiz = async () => {
    setState('SCORING');
    
    // Calculate local results
    const subjectScores: Record<string, { score: number, total: number }> = {};
    questions.forEach(q => {
      if (!subjectScores[q.subject]) subjectScores[q.subject] = { score: 0, total: 0 };
      subjectScores[q.subject].total += 1;
      if (answers[q.id] === q.correctAnswer) {
        subjectScores[q.subject].score += 1;
      }
    });

    const calculatedResults: TestResult[] = Object.entries(subjectScores).map(([name, data]) => ({
      subject: name,
      score: data.score,
      total: data.total,
      feedback: data.score / data.total < 0.6 ? 'Insufficient core understanding.' : 'Moderate grasp of concepts.'
    }));

    setResults(calculatedResults);

    try {
      const plan = await generateImprovementPlan(calculatedResults);
      setImprovementPlan(plan);
      setState('RESULT');
    } catch (e) {
      console.error(e);
      setState('RESULT');
    }
  };

  if (state === 'IDLE') {
    return (
      <div className="bg-slate-900/50 border border-slate-800 p-12 text-center space-y-8 animate-in fade-in duration-500">
        <div className="w-20 h-20 bg-cyan-500/10 border border-cyan-500/30 rounded-full flex items-center justify-center mx-auto">
          <svg className="w-10 h-10 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
          </svg>
        </div>
        <div className="space-y-2">
          <h2 className="text-3xl font-black text-white italic uppercase tracking-tighter">MOCK_TEST_PROTOCOL</h2>
          <p className="text-slate-400 mono text-sm max-w-md mx-auto uppercase">
            Initiate a diagnostic test to evaluate your current cognitive retention for Semester {context?.semester}.
          </p>
        </div>
        <button 
          onClick={startTest}
          disabled={!context}
          className="glitch-btn px-12 py-4 bg-cyan-500 text-slate-950 font-black tracking-[0.2em] uppercase italic hover:bg-white transition-all disabled:opacity-30"
        >
          {context ? 'INITIALIZE_TEST' : 'LOCKED: CONFIG_REQUIRED'}
        </button>
      </div>
    );
  }

  if (state === 'LOADING' || state === 'SCORING') {
    return (
      <div className="h-96 flex flex-col items-center justify-center space-y-6">
        <div className="w-16 h-16 border-4 border-cyan-500/20 border-t-cyan-500 rounded-full animate-spin"></div>
        <div className="text-cyan-400 mono text-xs tracking-widest animate-pulse uppercase">
          {state === 'LOADING' ? 'FETCHING_NEURAL_QUERIES...' : 'CALIBRATING_IMPROVEMENT_MATRIX...'}
        </div>
      </div>
    );
  }

  if (state === 'QUIZ') {
    return (
      <div className="space-y-8 animate-in slide-in-from-bottom-8 duration-500">
        <div className="flex justify-between items-end border-b border-slate-800 pb-4">
          <h3 className="text-xl font-black text-white uppercase italic tracking-tighter">ACTIVE_DIAGNOSTIC</h3>
          <span className="text-cyan-400 mono text-xs uppercase tracking-widest">Q_COUNT: {questions.length}</span>
        </div>
        
        <div className="space-y-12">
          {questions.map((q, idx) => (
            <div key={q.id} className="bg-slate-900 border-l-4 border-slate-700 p-8 space-y-6 group hover:border-cyan-500 transition-colors">
              <div className="space-y-1">
                <span className="text-[10px] font-black text-cyan-500 mono uppercase tracking-widest">{q.subject}</span>
                <h4 className="text-lg font-bold text-white uppercase italic">[{idx + 1}] {q.question}</h4>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {q.options.map((opt, oIdx) => (
                  <button
                    key={oIdx}
                    onClick={() => setAnswers({...answers, [q.id]: oIdx})}
                    className={`p-4 border text-left text-xs mono uppercase transition-all ${
                      answers[q.id] === oIdx 
                        ? 'bg-cyan-500 border-cyan-400 text-slate-950 font-black' 
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-600'
                    }`}
                  >
                    {String.fromCharCode(65 + oIdx)}. {opt}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        <button 
          onClick={submitQuiz}
          disabled={Object.keys(answers).length < questions.length}
          className="w-full py-6 bg-cyan-500 text-slate-950 font-black text-xl uppercase italic tracking-[0.3em] hover:bg-white transition-all disabled:opacity-30"
        >
          SUBMIT_FOR_ANALYSIS
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-12 animate-in fade-in duration-1000">
      <div className="border-l-4 border-lime-500 pl-6 space-y-1">
        <h2 className="text-4xl font-black text-white uppercase italic tracking-tighter">DIAGNOSTIC_RESULTS</h2>
        <p className="text-lime-400 mono text-xs uppercase tracking-widest">EVOLUTION_PLAN_GENERATED</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {results.map((res, i) => (
          <div key={i} className="bg-slate-900 border border-slate-800 p-6 flex flex-col items-center text-center space-y-4">
             <div className="text-[10px] font-black text-slate-500 mono uppercase tracking-widest">{res.subject}</div>
             <div className="text-5xl font-black text-white italic">{res.score}/{res.total}</div>
             <div className={`px-3 py-1 text-[8px] font-black mono uppercase ${res.score/res.total < 0.6 ? 'bg-red-500/20 text-red-500' : 'bg-lime-500/20 text-lime-500'}`}>
               {res.score/res.total < 0.6 ? 'STATUS_CRITICAL' : 'STATUS_OPTIMAL'}
             </div>
          </div>
        ))}
      </div>

      {improvementPlan && (
        <div className="bg-slate-900 border border-cyan-500 p-10 space-y-10 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10 mono text-[8px] uppercase">Improvement_Protocol_v2.1</div>
          
          <div className="space-y-4">
            <h3 className="text-2xl font-black text-white italic uppercase tracking-tighter flex items-center gap-3">
              <span className="w-2 h-6 bg-cyan-500"></span>
              IMPROVEMENT_PROTOCOL
            </h3>
            <p className="text-slate-400 text-sm mono leading-relaxed uppercase">{improvementPlan.summary}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {improvementPlan.subjectFocus.map((focus, i) => (
              <div key={i} className="bg-black/40 border border-slate-800 p-6 space-y-6">
                <div className="flex justify-between items-center">
                  <h4 className="font-black text-white uppercase italic tracking-widest text-sm">{focus.name}</h4>
                  <span className={`text-[8px] font-black mono px-2 py-1 ${
                    focus.priority === 'CRITICAL' ? 'bg-red-500 text-white' : 'bg-orange-500 text-slate-950'
                  }`}>
                    {focus.priority}
                  </span>
                </div>
                <ul className="space-y-3">
                  {focus.actionItems.map((item, ai) => (
                    <li key={ai} className="flex gap-3 text-xs mono text-slate-400 group">
                      <span className="text-cyan-500 font-black mt-1">»</span>
                      <span className="group-hover:text-white transition-colors uppercase leading-tight">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <button 
            onClick={() => setState('IDLE')}
            className="w-full py-4 border border-slate-700 text-slate-500 font-black uppercase text-xs mono hover:text-white hover:border-white transition-all"
          >
            TERMINATE_SESSION_&_REBOOT
          </button>
        </div>
      )}
    </div>
  );
};

export default MockTerminal;
