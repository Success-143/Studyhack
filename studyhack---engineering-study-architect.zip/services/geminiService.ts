
import { GoogleGenAI, Type } from "@google/genai";
import { UserContext, StudyPlan, CognitiveLoad, ActivityType, ChatMessage, MockQuestion, TestResult, ImprovementPlan } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const planSchema = {
  type: Type.OBJECT,
  properties: {
    schedule: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          day: { type: Type.STRING },
          startTime: { type: Type.STRING },
          endTime: { type: Type.STRING },
          subjectName: { type: Type.STRING },
          activityType: { 
            type: Type.STRING,
            description: "Must be one of: LEARNING, PRACTICE, REVISION, BUFFER"
          },
          cognitiveLoad: { 
            type: Type.STRING,
            description: "Must be one of: LOW, MEDIUM, HIGH"
          },
          description: { type: Type.STRING }
        },
        required: ["day", "startTime", "endTime", "subjectName", "activityType", "cognitiveLoad"]
      }
    },
    breakdown: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          allocationPercentage: { type: Type.NUMBER },
          hoursPerWeek: { type: Type.NUMBER },
          justification: { type: Type.STRING }
        },
        required: ["name", "allocationPercentage", "hoursPerWeek", "justification"]
      }
    },
    prioritizationLogic: { type: Type.STRING },
    nextSteps: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          timeframe: { type: Type.STRING },
          task: { type: Type.STRING },
          reason: { type: Type.STRING }
        },
        required: ["timeframe", "task", "reason"]
      }
    },
    outcomeSummary: {
      type: Type.OBJECT,
      properties: {
        completionTimeline: { type: Type.STRING },
        expectedConfidenceImprovement: { type: Type.STRING },
        workloadReductionImpact: { type: Type.STRING }
      },
      required: ["completionTimeline", "expectedConfidenceImprovement", "workloadReductionImpact"]
    }
  },
  required: ["schedule", "breakdown", "prioritizationLogic", "nextSteps", "outcomeSummary"]
};

export const generateStudyPlan = async (context: UserContext): Promise<StudyPlan> => {
  const prompt = `
    Act as an expert Academic Strategist for Engineering Students.
    Create a highly personalized, credits-weighted study plan for an engineering student in Year ${context.year}, Semester ${context.semester}, majoring in ${context.major || 'General Engineering'}.
    
    Current Subject Context:
    ${context.subjects.map(s => `- ${s.name}: ${s.credits} Credits, Current Confidence: ${s.confidence}/5, Key Topics: ${s.topics.join(', ')}`).join('\n')}
    
    Constraints:
    - Daily Study Capacity: ${context.availableHoursPerDay} hours.
    - Peak Focus Time: ${context.peakFocusHours}.
    - Allocate more time to subjects with Higher Credits and Lower Confidence.
    - Use Smart Prioritization: Prerequisite-heavy topics first, high-load topics during peak hours.
    
    Return the plan in strict JSON.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: planSchema
    }
  });

  return JSON.parse(response.text.trim()) as StudyPlan;
};

export const generateMockTest = async (subjects: string[]): Promise<MockQuestion[]> => {
  const schema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        id: { type: Type.INTEGER },
        subject: { type: Type.STRING },
        question: { type: Type.STRING },
        options: { type: Type.ARRAY, items: { type: Type.STRING } },
        correctAnswer: { type: Type.INTEGER, description: "Index of correct option (0-3)" }
      },
      required: ["id", "subject", "question", "options", "correctAnswer"]
    }
  };

  const prompt = `Generate a technical mock test for an engineering student. 
  Create 5 high-quality multiple choice questions covering these subjects: ${subjects.join(', ')}. 
  Questions should be challenging and conceptual. Ensure diversity across the subjects provided.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: schema
    }
  });

  return JSON.parse(response.text.trim()) as MockQuestion[];
};

export const generateImprovementPlan = async (results: TestResult[]): Promise<ImprovementPlan> => {
  const schema = {
    type: Type.OBJECT,
    properties: {
      summary: { type: Type.STRING },
      subjectFocus: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            actionItems: { type: Type.ARRAY, items: { type: Type.STRING } },
            priority: { type: Type.STRING, description: "Must be CRITICAL, MODERATE, or LOW" }
          },
          required: ["name", "actionItems", "priority"]
        }
      }
    },
    required: ["summary", "subjectFocus"]
  };

  const prompt = `Based on the following mock test results for an engineering student, create a tactical Improvement Plan.
  Results: ${JSON.stringify(results)}
  Identify weaknesses and provide 3-5 concrete action items per subject to bridge the knowledge gap. 
  The summary should be motivating but stern in its academic rigor.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: schema
    }
  });

  return JSON.parse(response.text.trim()) as ImprovementPlan;
};

export const getEngiBotResponse = async (history: ChatMessage[], message: string, context?: UserContext, plan?: StudyPlan) => {
  const systemInstruction = `
    You are EngiBot, a world-class AI tutor for engineering students. 
    You help clarify technical concepts, solve doubts, and give advice on the user's specific study plan.
    User's Current Plan context: ${plan ? JSON.stringify(plan.nextSteps) : 'No plan generated yet'}.
    User's Context: ${context ? `Year ${context.year}, Major ${context.major}` : 'General student'}.
    Keep responses concise, encouraging, and technically accurate. Use Markdown for formatting.
  `;

  const chat = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: { systemInstruction }
  });

  const result = await chat.sendMessage({ message });
  return result.text;
};
