
import React, { useState } from 'react';
import { UserContext, StudyPlan } from './types';
import { generateStudyPlan } from './services/geminiService';
import StudyForm from './components/StudyForm';
import PlanDashboard from './components/PlanDashboard';
import SyllabusDashboard from './components/SyllabusDashboard';
import MockTerminal from './components/MockTerminal';
import EngiBot from './components/EngiBot';

type ActiveTab = 'ARCHITECT' | 'SYLLABUS' | 'MOCK_TEST';

const App: React.FC = () => {
  const [showLanding, setShowLanding] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [plan, setPlan] = useState<StudyPlan | null>(null);
  const [userContext, setUserContext] = useState<UserContext | null>(null);
  const [activeTab, setActiveTab] = useState<ActiveTab>('ARCHITECT');

  const handleFormSubmit = async (context: UserContext) => {
    setLoading(true);
    setError(null);
    setUserContext(context);
    try {
      const generatedPlan = await generateStudyPlan(context);
      setPlan(generatedPlan);
      setActiveTab('ARCHITECT');
    } catch (err: any) {
      setError(err.message || 'SYSTEM ERROR: PLAN GENERATION FAILED.');
    } finally {
      setLoading(false);
    }
  };

  const resetPlan = () => {
    setPlan(null);
    setError(null);
    setShowLanding(false);
  };

  const sidebarItems = [
    { id: 'ARCHITECT' as ActiveTab, label: 'PLAN_ARCHITECT', icon: 'M13 10V3L4 14h7v7l9-11h-7z' },
    { id: 'SYLLABUS' as ActiveTab, label: 'SYLLABUS_INDEX', icon: 'M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253' },
    { id: 'MOCK_TEST' as ActiveTab, label: 'MOCK_TERMINAL', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2' }
  ];

  return (
    <div className="min-h-screen flex flex-col relative overflow-x-hidden">
      {showLanding ? (
        <div className="flex-grow flex flex-col items-center justify-center px-4 relative z-20">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none"></div>
          
          <div className="max-w-4xl w-full text-center space-y-12 animate-in fade-in zoom-in duration-1000">
            <div className="inline-flex items-center gap-2 px-6 py-2 bg-slate-900/80 border border-cyan-500/30 rounded-full backdrop-blur-md">
              <span className="flex h-2 w-2 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_#22d3ee]"></span>
              <span className="text-xs font-bold text-cyan-400 uppercase tracking-[0.3em] mono">Connection Established // v2.0.7</span>
            </div>
            
            <div className="space-y-2">
              <h1 className="text-7xl md:text-9xl font-black text-white tracking-tighter leading-none italic uppercase">
                STUDY<span className="text-cyan-400 neon-text-cyan">HACK</span>
              </h1>
              <div className="h-1 w-full bg-gradient-to-r from-transparent via-cyan-500 to-transparent"></div>
            </div>
            
            <p className="text-xl md:text-2xl text-slate-400 max-w-2xl mx-auto font-light leading-relaxed mono">
              INITIALIZING ACADEMIC OVERRIDE. <br/>
              OPTIMIZING COGNITIVE THROUGHPUT FOR SEAMLESS GRADE ELEVATION.
            </p>
            
            <div className="pt-8">
              <button 
                onClick={() => setShowLanding(false)}
                className="glitch-btn group relative inline-flex items-center gap-6 bg-cyan-500 text-slate-950 px-12 py-6 rounded-none font-black text-2xl tracking-widest hover:bg-white transition-all skew-x-[-12deg]"
              >
                <span className="skew-x-[12deg]">START TO HACK</span>
                <svg className="w-8 h-8 group-hover:translate-x-2 transition-transform skew-x-[12deg]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="flex-grow flex">
          {/* Persistent Sidebar */}
          <aside className="w-20 md:w-64 bg-slate-950 border-r border-slate-900 flex flex-col h-screen sticky top-0 z-[60]">
            <div className="p-6 flex items-center gap-3 cursor-pointer group mb-10" onClick={() => setShowLanding(true)}>
              <div className="w-10 h-10 bg-cyan-500 rounded-sm flex items-center justify-center rotate-45 group-hover:rotate-[225deg] transition-transform duration-700 shrink-0">
                <span className="text-slate-950 font-black italic -rotate-45 group-hover:rotate-[-225deg] transition-transform duration-700">S</span>
              </div>
              <h1 className="text-xl font-black text-white tracking-tighter uppercase italic hidden md:block">
                STUDY<span className="text-cyan-400">HACK</span>
              </h1>
            </div>

            <nav className="flex-grow space-y-2 px-3">
              {sidebarItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center gap-4 p-4 transition-all duration-300 relative group overflow-hidden ${
                    activeTab === item.id 
                      ? 'bg-cyan-500 text-slate-950 shadow-[0_0_20px_rgba(6,182,212,0.3)]' 
                      : 'text-slate-500 hover:text-white hover:bg-slate-900/50'
                  }`}
                >
                  <svg className="w-6 h-6 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={item.icon} />
                  </svg>
                  <span className="text-xs font-black mono tracking-widest uppercase hidden md:block">{item.label}</span>
                  {activeTab === item.id && (
                    <div className="absolute right-0 top-0 bottom-0 w-1 bg-white"></div>
                  )}
                </button>
              ))}
            </nav>

            <div className="p-4 border-t border-slate-900 space-y-4">
               {userContext && (
                 <div className="hidden md:block">
                   <div className="text-[10px] text-slate-600 mono font-black uppercase mb-1">SYSTEM_ID</div>
                   <div className="text-[10px] text-cyan-400 mono font-black uppercase truncate">{userContext.major}</div>
                 </div>
               )}
               <button onClick={resetPlan} className="w-full flex items-center justify-center p-3 text-slate-600 hover:text-red-500 transition-colors">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" /></svg>
               </button>
            </div>
          </aside>

          {/* Content Area */}
          <div className="flex-grow flex flex-col">
            <header className="bg-slate-950/50 border-b border-cyan-500/10 h-20 flex items-center justify-between px-8 backdrop-blur-md sticky top-0 z-50">
              <div className="flex items-center gap-4">
                <span className="text-xs font-black text-slate-600 mono uppercase tracking-[0.3em]">LOC: {activeTab}</span>
                <div className="h-4 w-px bg-slate-800"></div>
                {userContext && <span className="text-xs font-black text-cyan-500 mono uppercase tracking-widest">SEM_{userContext.semester}.0</span>}
              </div>
              
              <div className="flex items-center gap-6">
                <div className="flex flex-col items-end">
                  <div className="flex items-center gap-2 text-[10px] font-black text-cyan-400 mono tracking-widest uppercase">
                     <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-ping"></span>
                     CYBER_LINK_ACTIVE
                  </div>
                  <div className="text-[10px] text-slate-500 mono">PROTOCOL: V.SYS</div>
                </div>
              </div>
            </header>

            <main className="p-8 md:p-12 max-w-7xl w-full mx-auto">
              {activeTab === 'ARCHITECT' && (
                <div className="animate-in fade-in slide-in-from-bottom-8 duration-700">
                  {!plan ? (
                    <div className="space-y-16">
                      <div className="text-center space-y-6 max-w-3xl mx-auto">
                        <div className="inline-block px-4 py-1 bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-bold tracking-[0.4em] uppercase mb-4">
                          INITIALIZING ACADEMIC ARCHITECT
                        </div>
                        <h2 className="text-5xl md:text-6xl font-black text-white leading-none uppercase italic">
                          OPTIMIZE YOUR <span className="text-cyan-400 neon-text-cyan">SEMESTER</span>
                        </h2>
                      </div>
                      <StudyForm onSubmit={handleFormSubmit} loading={loading} />
                    </div>
                  ) : (
                    <div className="space-y-12">
                       <div className="border-l-4 border-cyan-500 pl-6 space-y-1">
                        <h2 className="text-4xl font-black text-white uppercase italic tracking-tighter">SCHEDULE_MAP_ACTIVE</h2>
                        <p className="text-slate-500 mono text-xs uppercase tracking-widest mt-1">
                          {userContext?.major} // YEAR_{userContext?.year} // SEM_{userContext?.semester}
                        </p>
                      </div>
                      <PlanDashboard plan={plan} />
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'SYLLABUS' && (
                <SyllabusDashboard subjects={userContext?.subjects || []} />
              )}

              {activeTab === 'MOCK_TEST' && (
                <MockTerminal context={userContext || undefined} />
              )}

              {error && (
                <div className="mt-8 bg-red-500/10 border border-red-500/30 p-6 flex items-center gap-4 text-red-500">
                  <svg className="w-6 h-6 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                  <p className="mono text-xs font-black uppercase tracking-widest">{error}</p>
                </div>
              )}
            </main>

            <footer className="py-12 border-t border-slate-900 bg-slate-950/50 mt-auto">
              <div className="max-w-7xl mx-auto px-4 text-center space-y-4">
                <p className="text-slate-600 text-[10px] font-black tracking-[0.5em] uppercase mono">
                  © STUDYHACK // NEURAL NETWORK PROTOCOL // {new Date().getFullYear()}
                </p>
              </div>
            </footer>
          </div>
          
          <EngiBot context={userContext || undefined} plan={plan || undefined} />
        </div>
      )}
    </div>
  );
};

export default App;
