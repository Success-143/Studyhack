
export enum CognitiveLoad {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH'
}

export enum ActivityType {
  LEARNING = 'LEARNING',
  PRACTICE = 'PRACTICE',
  REVISION = 'REVISION',
  BUFFER = 'BUFFER'
}

export interface SubjectInput {
  id: string;
  name: string;
  credits: number;
  confidence: number; // 1-5
  topics: string[];
}

export interface TimeSlot {
  day: string;
  startTime: string;
  endTime: string;
  subjectName: string;
  activityType: ActivityType;
  cognitiveLoad: CognitiveLoad;
  description: string;
}

export interface SubjectBreakdown {
  name: string;
  allocationPercentage: number;
  hoursPerWeek: number;
  justification: string;
}

export interface ActionableStep {
  timeframe: string;
  task: string;
  reason: string;
}

export interface StudyPlan {
  schedule: TimeSlot[];
  breakdown: SubjectBreakdown[];
  prioritizationLogic: string;
  nextSteps: ActionableStep[];
  outcomeSummary: {
    completionTimeline: string;
    expectedConfidenceImprovement: string;
    workloadReductionImpact: string;
  };
}

export interface UserContext {
  year: number;
  semester: number;
  major?: string;
  subjects: SubjectInput[];
  availableHoursPerDay: number;
  peakFocusHours: 'morning' | 'afternoon' | 'evening' | 'night';
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface MockQuestion {
  id: number;
  subject: string;
  question: string;
  options: string[];
  correctAnswer: number;
}

export interface TestResult {
  subject: string;
  score: number;
  total: number;
  feedback: string;
}

export interface ImprovementPlan {
  summary: string;
  subjectFocus: {
    name: string;
    actionItems: string[];
    priority: 'CRITICAL' | 'MODERATE' | 'LOW';
  }[];
}
